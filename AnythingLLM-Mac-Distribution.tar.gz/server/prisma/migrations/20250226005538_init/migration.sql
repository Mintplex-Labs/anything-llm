-- AlterTable
ALTER TABLE "users" ADD COLUMN "bio" TEXT DEFAULT '';
