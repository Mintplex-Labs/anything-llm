-- AlterTable
ALTER TABLE "workspaces" ADD COLUMN "chatProvider" TEXT;
